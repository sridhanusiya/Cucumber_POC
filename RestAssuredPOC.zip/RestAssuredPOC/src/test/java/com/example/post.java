package com.example;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;

public class post 
{
	@Test
	public void test_post()
	{
		JSONObject request = new JSONObject();
		request.put("firstName", "Thomas");
		request.put("lastName","AlvaEdison");
		request.put("subjectId",1);
		
		baseURI="http://localhost:3000/";
		
		given().
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			header("Content-Type","application/json").
			body(request.toJSONString()).
		when().
			post("/user").
		then()
			.statusCode(201);
		
	}
	}