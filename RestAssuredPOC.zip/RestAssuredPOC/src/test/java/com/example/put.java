package com.example;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;

public class put 
{
	//@Test
	public void test_put()
	{
		JSONObject request = new JSONObject();
		request.put("firstName", "Tom");
		request.put("lastName","Jerry");
		request.put("subjectId",1);
		
		baseURI="http://localhost:3000/";
		
		given().
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			header("Content-Type","application/json").
			body(request.toJSONString()).
		when().
			put("/user/2").
		then()
			.statusCode(200);
		
	}
	//@Test
	public void test_patch()
	{
		JSONObject request = new JSONObject();
		request.put("lastName", "Edison");
				
		baseURI="http://localhost:3000/";
		
		given().
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			header("Content-Type","application/json").
			body(request.toJSONString()).
		when().
			patch("/user/4").
		then()
			.statusCode(200);
		
	}
	
	@Test
	public void test_delete()
	{
			
		baseURI="http://localhost:3000/";
		
		given().
			contentType(ContentType.JSON).
			accept(ContentType.JSON).
			header("Content-Type","application/json").
		when().
			delete("/user/4").
		then()
			.statusCode(200);
		
	}
}