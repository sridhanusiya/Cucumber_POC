package com.example;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
public class Example1 
{
	@Test
	public void get()
	{
	baseURI="http://localhost:3000/";
	
	given().
		param("name","Automation").
		get("/subjects").
	then().
		statusCode(200).
		log().all();
	}

}
