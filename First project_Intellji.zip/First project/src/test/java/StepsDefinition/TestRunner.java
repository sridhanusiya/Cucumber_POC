package StepsDefinition;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Feature/login.feature", glue= {"StepsDefinition"},
        monochrome= true, tags="@smoke")

public class TestRunner {
}
